1- Before you start, you need to talk to @BotFather on Telegram. Create a new bot, acquire the bot token and get back here.

2- You have to install requirement Libraries. Please run this command in the current folder.
pip3 install -r requirements.txt

5- You can adjust the settings in the main.py(Email-password-Token).

6- Open the terminal, run and enjoy it ! :)
python main.py 

For running: 

When you're running the main_withMessage make sure you send your bot a random message, it just needs to be some short text. 
The bot needs to know which chat to contact. 


